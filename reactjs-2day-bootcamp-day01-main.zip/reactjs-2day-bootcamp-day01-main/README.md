# reactjs-2day-bootcamp-day01
This is the first of two days of ReactJS boot camp with Axle Barr.

In this two day ReactJS bootcamp we will build a simple application with components. The course focusses on getting started with ReactJS. After building the boilerplate app, we will discuss and demo two key features of React which are Hooks and State. These concepts are used to pass data from one component to the other, mainly from parent to child and back up the chain.
On Day2 we will build a second app. We will add components, organize them and build a menu system to display those components. We will also add a mock database system to the apps so that we can work with CRUD operations (API calls). On this day we also look at the Class architecture in React. This is an alternative to using Hooks. 
The instructor will be using a Linux environment with VS Code as an editor. Any OS + Editor can be used, however NodeJS and NPM must be installed. 
